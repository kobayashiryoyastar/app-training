﻿using ItemManager;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows.Forms;

namespace ItemsManager
{
    public partial class frmItemRegister : Form
    {
        public frmItemRegister()
        {
            InitializeComponent();
        }

        /// <summary>
        /// フォーム表示時
        /// </summary>
        private void frmItemRegister_Load(object sender, EventArgs e)
        {
            InitializeForm();
        }

        /// <summary>
        /// 入力項目初期化
        /// </summary>
        private void InitializeForm()
        {
            txtItemName.Clear();
            txtPurchasePrice.Clear();
            txtServiceLife.Clear();

            dtpPurchaseDate.CustomFormat = " ";

            lblErrorMessage.Text = "";
        }
        private void dtpPurchaseDate_ValueChanged(object sender, EventArgs e)
        {
            // ユーザーが日付を選択・変更したら表示フォーマットを戻す
            dtpPurchaseDate.CustomFormat = "yyyy/MM/dd";
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";

            // ==========================
            // 必須入力チェック
            // ==========================
            if (!Validation.IsInputNotEmpty(txtItemName.Text))
            {
                lblErrorMessage.Text = "資産名を入力してください。";
                txtItemName.Focus();
                return;
            }

            if (!Validation.IsInputNotEmpty(txtPurchasePrice.Text))
            {
                lblErrorMessage.Text = "取得金額を入力してください。";
                txtPurchasePrice.Focus();
                return;
            }

            if (!Validation.IsInputNotEmpty(txtServiceLife.Text))
            {
                lblErrorMessage.Text = "耐用年数を入力してください。";
                txtServiceLife.Focus();
                return;
            }

            // ==========================
            // 資産名文字数チェック
            // ==========================
            if (!Validation.IsLengthValid(txtItemName.Text))
            {
                lblErrorMessage.Text = "資産名は30文字以内で入力してください。";
                txtItemName.Focus();
                return;
            }

            // ==========================
            // 取得金額数値チェック
            // ==========================
            if (!Validation.IsNumericValid(txtPurchasePrice.Text))
            {
                lblErrorMessage.Text = "取得金額は半角数字で入力してください。";
                txtPurchasePrice.Focus();
                return;
            }

            // ==========================
            // 耐用年数数値チェック
            // ==========================
            if (!Validation.IsNumericValid(txtServiceLife.Text))
            {
                lblErrorMessage.Text = "耐用年数は半角数字で入力してください。";
                txtServiceLife.Focus();
                return;
            }

            // ==========================
            // 取得金額 1以上チェック
            // ==========================
            if (!Validation.IsGreaterThanZero(txtPurchasePrice.Text))
            {
                lblErrorMessage.Text = "取得金額は1以上で入力してください。";
                txtPurchasePrice.Focus();
                return;
            }

            // ==========================
            // 耐用年数 1年以上チェック
            // ==========================
            if (!Validation.IsGreaterThanZero(txtServiceLife.Text))
            {
                lblErrorMessage.Text = "耐用年数は1以上で入力してください。";
                txtServiceLife.Focus();
                return;
            }

            // 入力内容から資産情報を作成
            Item item = new Item
            {
                ItemName = txtItemName.Text,
                PurchaseDate = dtpPurchaseDate.Value,
                PurchasePrice = decimal.Parse(txtPurchasePrice.Text),
                ServiceLife = int.Parse(txtServiceLife.Text)
            };

            try
            {
                ItemDao dao = new ItemDao();

                // 登録処理の実行
                bool result = dao.Insert(item);

                if (result)
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    lblErrorMessage.Text = "資産情報の登録に失敗しました。";
                }
            }
            catch (OracleException)
            {
                // データベース接続障害時
                lblErrorMessage.Text = "資産情報の登録に失敗しました。";
            }
            catch (Exception)
            {

                lblErrorMessage.Text = "資産情報の登録に失敗しました。";
            }
        }

        /// <summary>
        /// キャンセル
        /// </summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 取得金額入力制御
        /// 半角数字のみ入力可能
        /// </summary>
        private void txtPurchasePrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) &&
                !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 耐用年数入力制御
        /// 半角数字のみ入力可能
        /// </summary>
        private void txtServiceLife_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) &&
                !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // -------------------------
        // 以下はデザイナーが自動生成したイベント
        // （処理なし）
        // -------------------------

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

       
    }
}