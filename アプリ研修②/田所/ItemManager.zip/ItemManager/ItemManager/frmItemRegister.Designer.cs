﻿namespace ItemsManager
{
    partial class frmItemRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRegister = new Button();
            btnCancel = new Button();
            lblTitle = new Label();
            lblItemName = new Label();
            lblPurchaseDate = new Label();
            lblPurchasePrice = new Label();
            lblServiceLife = new Label();
            txtItemName = new TextBox();
            txtPurchasePrice = new TextBox();
            txtServiceLife = new TextBox();
            dtpPurchaseDate = new DateTimePicker();
            lblErrorMessage = new Label();
            SuspendLayout();
            // 
            // btnRegister
            // 
            btnRegister.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnRegister.Font = new Font("游ゴシック", 10.8F, FontStyle.Bold);
            btnRegister.Location = new Point(307, 387);
            btnRegister.Margin = new Padding(5, 4, 5, 4);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(160, 40);
            btnRegister.TabIndex = 3;
            btnRegister.Text = "登録";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnCancel.Font = new Font("游ゴシック", 10.8F, FontStyle.Bold);
            btnCancel.Location = new Point(569, 387);
            btnCancel.Margin = new Padding(5, 4, 5, 4);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(160, 40);
            btnCancel.TabIndex = 4;
            btnCancel.Text = "キャンセル";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("游ゴシック", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 128);
            lblTitle.Location = new Point(20, 12);
            lblTitle.Margin = new Padding(5, 0, 5, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(127, 36);
            lblTitle.TabIndex = 5;
            lblTitle.Text = "新規登録";
            // 
            // lblItemName
            // 
            lblItemName.AutoSize = true;
            lblItemName.Font = new Font("游ゴシック Medium", 12F, FontStyle.Bold);
            lblItemName.Location = new Point(172, 66);
            lblItemName.Margin = new Padding(5, 0, 5, 0);
            lblItemName.Name = "lblItemName";
            lblItemName.Size = new Size(75, 26);
            lblItemName.TabIndex = 6;
            lblItemName.Text = "資産名";
            // 
            // lblPurchaseDate
            // 
            lblPurchaseDate.AutoSize = true;
            lblPurchaseDate.Font = new Font("游ゴシック Medium", 12F, FontStyle.Bold);
            lblPurchaseDate.Location = new Point(172, 140);
            lblPurchaseDate.Margin = new Padding(5, 0, 5, 0);
            lblPurchaseDate.Name = "lblPurchaseDate";
            lblPurchaseDate.Size = new Size(75, 26);
            lblPurchaseDate.TabIndex = 7;
            lblPurchaseDate.Text = "取得日";
            // 
            // lblPurchasePrice
            // 
            lblPurchasePrice.AutoSize = true;
            lblPurchasePrice.Font = new Font("游ゴシック Medium", 12F, FontStyle.Bold);
            lblPurchasePrice.Location = new Point(172, 202);
            lblPurchasePrice.Margin = new Padding(5, 0, 5, 0);
            lblPurchasePrice.Name = "lblPurchasePrice";
            lblPurchasePrice.Size = new Size(96, 26);
            lblPurchasePrice.TabIndex = 8;
            lblPurchasePrice.Text = "取得金額";
            // 
            // lblServiceLife
            // 
            lblServiceLife.AutoSize = true;
            lblServiceLife.Font = new Font("游ゴシック Medium", 12F, FontStyle.Bold);
            lblServiceLife.Location = new Point(172, 277);
            lblServiceLife.Margin = new Padding(5, 0, 5, 0);
            lblServiceLife.Name = "lblServiceLife";
            lblServiceLife.Size = new Size(96, 26);
            lblServiceLife.TabIndex = 9;
            lblServiceLife.Text = "耐用年数";
            // 
            // txtItemName
            // 
            txtItemName.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtItemName.Location = new Point(307, 63);
            txtItemName.Margin = new Padding(5, 4, 5, 4);
            txtItemName.Name = "txtItemName";
            txtItemName.Size = new Size(422, 40);
            txtItemName.TabIndex = 10;
            // 
            // txtPurchasePrice
            // 
            txtPurchasePrice.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtPurchasePrice.Location = new Point(307, 202);
            txtPurchasePrice.Margin = new Padding(5, 4, 5, 4);
            txtPurchasePrice.Name = "txtPurchasePrice";
            txtPurchasePrice.Size = new Size(422, 40);
            txtPurchasePrice.TabIndex = 11;
            // 
            // txtServiceLife
            // 
            txtServiceLife.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtServiceLife.Location = new Point(307, 274);
            txtServiceLife.Margin = new Padding(5, 4, 5, 4);
            txtServiceLife.Name = "txtServiceLife";
            txtServiceLife.Size = new Size(422, 40);
            txtServiceLife.TabIndex = 12;
            // 
            // dtpPurchaseDate
            // 
            dtpPurchaseDate.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dtpPurchaseDate.Format = DateTimePickerFormat.Custom;
            dtpPurchaseDate.Location = new Point(307, 131);
            dtpPurchaseDate.Margin = new Padding(5, 4, 5, 4);
            dtpPurchaseDate.Name = "dtpPurchaseDate";
            dtpPurchaseDate.Size = new Size(422, 40);
            dtpPurchaseDate.TabIndex = 13;
            dtpPurchaseDate.ValueChanged += dtpPurchaseDate_ValueChanged;
            // 
            // lblErrorMessage
            // 
            lblErrorMessage.AutoSize = true;
            lblErrorMessage.Font = new Font("游ゴシック Medium", 12F, FontStyle.Bold);
            lblErrorMessage.ForeColor = Color.Red;
            lblErrorMessage.Location = new Point(172, 339);
            lblErrorMessage.Margin = new Padding(5, 0, 5, 0);
            lblErrorMessage.Name = "lblErrorMessage";
            lblErrorMessage.Size = new Size(0, 26);
            lblErrorMessage.TabIndex = 14;
            // 
            // frmItemRegister
            // 
            AutoScaleDimensions = new SizeF(13F, 26F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(903, 452);
            Controls.Add(lblErrorMessage);
            Controls.Add(dtpPurchaseDate);
            Controls.Add(txtServiceLife);
            Controls.Add(txtPurchasePrice);
            Controls.Add(txtItemName);
            Controls.Add(lblServiceLife);
            Controls.Add(lblPurchasePrice);
            Controls.Add(lblPurchaseDate);
            Controls.Add(lblItemName);
            Controls.Add(lblTitle);
            Controls.Add(btnCancel);
            Controls.Add(btnRegister);
            Font = new Font("游ゴシック Medium", 12F, FontStyle.Bold);
            Margin = new Padding(5, 4, 5, 4);
            Name = "frmItemRegister";
            Text = "新規登録";
            Load += frmItemRegister_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnRegister;
        private Button btnCancel;
        private Label lblTitle;
        private Label lblItemName;
        private Label lblPurchaseDate;
        private Label lblPurchasePrice;
        private Label lblServiceLife;
        private TextBox txtItemName;
        private TextBox txtPurchasePrice;
        private TextBox txtServiceLife;
        private DateTimePicker dtpPurchaseDate;
        private Label lblErrorMessage;
    }
}