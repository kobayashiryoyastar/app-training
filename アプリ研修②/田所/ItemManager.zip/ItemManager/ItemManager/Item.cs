﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ItemManager
{
    public class Item
    {
        // 資産ID（主キー）
        public int ItemId { get; set; }

        // 資産名
        public string ItemName { get; set; } = string.Empty;

        // 取得日
        public DateTime PurchaseDate { get; set; }

        // 取得金額
        public decimal PurchasePrice { get; set; }

        // 耐用年数（年）
        public int ServiceLife { get; set; }

        // 減価償却後の帳簿価格
        // DBには保存せず、Calculatorで計算した結果を保持する。
        public decimal BookValue { get; set; }

        // 資産の状態（使用中・償却完了）
        // BookValueからCalculatorで判定する。
        public string Status { get; set; } = string.Empty;
    }
}
