﻿namespace ItemsManager
{
    partial class frmItemList
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            btnSearch = new Button();
            btnOpenRegister = new Button();
            btnDeleteItem = new Button();
            lblTitle = new Label();
            lblSearchKeyword = new Label();
            lblItemList = new Label();
            lblErrorMessage = new Label();
            txtSearchKeyword = new TextBox();
            dgvItemList = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvItemList).BeginInit();
            SuspendLayout();
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSearch.Font = new Font("游ゴシック", 10.8F, FontStyle.Bold);
            btnSearch.Location = new Point(631, 61);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(160, 40);
            btnSearch.TabIndex = 0;
            btnSearch.Text = "検索";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnOpenRegister
            // 
            btnOpenRegister.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnOpenRegister.Font = new Font("游ゴシック", 10.8F, FontStyle.Bold);
            btnOpenRegister.Location = new Point(244, 398);
            btnOpenRegister.Name = "btnOpenRegister";
            btnOpenRegister.Size = new Size(160, 40);
            btnOpenRegister.TabIndex = 1;
            btnOpenRegister.Text = "新規登録";
            btnOpenRegister.UseVisualStyleBackColor = true;
            btnOpenRegister.Click += btnOpenRegister_Click;
            // 
            // btnDeleteItem
            // 
            btnDeleteItem.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnDeleteItem.Font = new Font("游ゴシック", 10.8F, FontStyle.Bold);
            btnDeleteItem.Location = new Point(465, 398);
            btnDeleteItem.Name = "btnDeleteItem";
            btnDeleteItem.Size = new Size(160, 40);
            btnDeleteItem.TabIndex = 2;
            btnDeleteItem.Text = "削除";
            btnDeleteItem.UseVisualStyleBackColor = true;
            btnDeleteItem.Click += btnDeleteItem_Click;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("游ゴシック", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 128);
            lblTitle.Location = new Point(12, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(238, 36);
            lblTitle.TabIndex = 11;
            lblTitle.Text = "資産管理システム";
            // 
            // lblSearchKeyword
            // 
            lblSearchKeyword.AutoSize = true;
            lblSearchKeyword.Font = new Font("游ゴシック", 12F, FontStyle.Bold);
            lblSearchKeyword.Location = new Point(86, 64);
            lblSearchKeyword.Name = "lblSearchKeyword";
            lblSearchKeyword.Size = new Size(152, 26);
            lblSearchKeyword.TabIndex = 4;
            lblSearchKeyword.Text = "検索キーワード";
            // 
            // lblItemList
            // 
            lblItemList.AutoSize = true;
            lblItemList.Font = new Font("游ゴシック", 12F, FontStyle.Bold);
            lblItemList.Location = new Point(106, 97);
            lblItemList.Name = "lblItemList";
            lblItemList.Size = new Size(132, 26);
            lblItemList.TabIndex = 5;
            lblItemList.Text = "＜資産一覧＞";
            // 
            // lblErrorMessage
            // 
            lblErrorMessage.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblErrorMessage.AutoSize = true;
            lblErrorMessage.Font = new Font("游ゴシック", 10.8F, FontStyle.Bold);
            lblErrorMessage.ForeColor = Color.Red;
            lblErrorMessage.Location = new Point(128, 366);
            lblErrorMessage.Name = "lblErrorMessage";
            lblErrorMessage.Size = new Size(0, 23);
            lblErrorMessage.TabIndex = 6;
            // 
            // txtSearchKeyword
            // 
            txtSearchKeyword.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtSearchKeyword.Font = new Font("游ゴシック", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 128);
            txtSearchKeyword.Location = new Point(244, 61);
            txtSearchKeyword.Name = "txtSearchKeyword";
            txtSearchKeyword.Size = new Size(381, 36);
            txtSearchKeyword.TabIndex = 7;
            // 
            // dgvItemList
            // 
            dgvItemList.AllowUserToAddRows = false;
            dgvItemList.AllowUserToResizeColumns = false;
            dgvItemList.AllowUserToResizeRows = false;
            dgvItemList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvItemList.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvItemList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Window;
            dataGridViewCellStyle1.Font = new Font("Yu Gothic UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 128);
            dataGridViewCellStyle1.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvItemList.DefaultCellStyle = dataGridViewCellStyle1;
            dgvItemList.Location = new Point(162, 126);
            dgvItemList.Name = "dgvItemList";
            dgvItemList.ReadOnly = true;
            dgvItemList.RowHeadersWidth = 51;
            dgvItemList.Size = new Size(629, 224);
            dgvItemList.TabIndex = 8;
            dgvItemList.CellContentClick += dgvItemList_CellContentClick;
            // 
            // frmItemList
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            ClientSize = new Size(900, 450);
            Controls.Add(btnSearch);
            Controls.Add(dgvItemList);
            Controls.Add(txtSearchKeyword);
            Controls.Add(lblErrorMessage);
            Controls.Add(lblItemList);
            Controls.Add(lblSearchKeyword);
            Controls.Add(lblTitle);
            Controls.Add(btnDeleteItem);
            Controls.Add(btnOpenRegister);
            Font = new Font("Yu Gothic UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Name = "frmItemList";
            Text = "資産管理システム";
            Load += frmItemList_Load;
            ((System.ComponentModel.ISupportInitialize)dgvItemList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSearch;
        private Button btnOpenRegister;
        private Button btnDeleteItem;
        private Label lblTitle;
        private Label lblSearchKeyword;
        private Label lblItemList;
        private Label lblErrorMessage;
        private TextBox txtSearchKeyword;
        private DataGridView dgvItemList;
    }
}