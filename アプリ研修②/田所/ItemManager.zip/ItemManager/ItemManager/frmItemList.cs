﻿using System;
using System.Windows.Forms;
using ItemManager;
using Oracle.ManagedDataAccess.Client; // Oracleデータベースに接続するためのライブラリを利用

namespace ItemsManager
{
    // 資産一覧画面を表すクラス（Form）
    public partial class frmItemList : Form
    {
        /// <summary>
        /// 現在一覧上でユーザーが選択している資産のID（初期値は未選択を表す -1）
        /// </summary>
        private int selectedItemId = -1;

        // 画面（フォーム）を作成する時の初期処理
        public frmItemList()
        {
            InitializeComponent(); // 画面に配置されたボタンや表などの部品を初期化・準備する
        }

        /// <summary>
        /// 画面が一番最初に出現・表示された時に自動的に実行される処理
        /// </summary>
        private void frmItemList_Load(object sender, EventArgs e)
        {
            // データの自動列追加機能をオフ
            dgvItemList.AutoGenerateColumns = false;

            // 行選択モード・単一選択
            dgvItemList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvItemList.MultiSelect = false;

            // 余分な矢印ヘッダー列を非表示
            dgvItemList.RowHeadersVisible = false;

            // ヘッダーの中央揃え＆カスタムスタイル有効化
            dgvItemList.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvItemList.EnableHeadersVisualStyles = false;

            // ★追加：データバインドが完了したタイミングで自動的に行選択を解除する
            dgvItemList.DataBindingComplete += (s, args) => dgvItemList.ClearSelection();

            // デザイン設定
            InitializeLayout();

            // データ取得＆表示
            DisplayData();
        }

        /// <summary>
        /// 表（DataGridView）の見た目・各列の項目・表示形式を設定する処理
        /// </summary>
        private void InitializeLayout()
        {
            // 1. 行全体の選択に固定
            dgvItemList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // 2. 複数行選択の禁止
            dgvItemList.MultiSelect = false;

            // 3. 読み取り専用化
            dgvItemList.ReadOnly = true;

            // 4. カスタムスタイルを有効化
            dgvItemList.EnableHeadersVisualStyles = false;

            // 5. 行選択時に列ヘッダーの色が変わらないように背景色・文字色を通常時と同色に固定
            dgvItemList.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                dgvItemList.ColumnHeadersDefaultCellStyle.BackColor;
            dgvItemList.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                dgvItemList.ColumnHeadersDefaultCellStyle.ForeColor;

            // 不要な列を一度リセット
            dgvItemList.Columns.Clear();

            // 列の追加
            dgvItemList.Columns.Add("ItemId", "ID");
            dgvItemList.Columns.Add("ItemName", "資産名");
            dgvItemList.Columns.Add("PurchaseDate", "取得日");
            dgvItemList.Columns.Add("PurchasePrice", "取得金額");
            dgvItemList.Columns.Add("BookValue", "帳簿価格");
            dgvItemList.Columns.Add("Status", "ステータス");

            // プロパティ名との紐付け
            dgvItemList.Columns["ItemId"].DataPropertyName = "ItemId";
            dgvItemList.Columns["ItemName"].DataPropertyName = "ItemName";
            dgvItemList.Columns["PurchaseDate"].DataPropertyName = "PurchaseDate";
            dgvItemList.Columns["PurchasePrice"].DataPropertyName = "PurchasePrice";
            dgvItemList.Columns["BookValue"].DataPropertyName = "BookValue";
            dgvItemList.Columns["Status"].DataPropertyName = "Status";

            // 幅の比率
            dgvItemList.Columns["ItemId"].FillWeight = 50;
            dgvItemList.Columns["ItemName"].FillWeight = 160;
            dgvItemList.Columns["PurchaseDate"].FillWeight = 95;
            dgvItemList.Columns["PurchasePrice"].FillWeight = 100;
            dgvItemList.Columns["BookValue"].FillWeight = 100;
            dgvItemList.Columns["Status"].FillWeight = 95;

            dgvItemList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // セル内の自動折り返し・中央揃え
            dgvItemList.Columns["ItemName"]!.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dgvItemList.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvItemList.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // 高さ調整
            dgvItemList.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvItemList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvItemList.ColumnHeadersHeight = 40;

            // フォーマット指定
            dgvItemList.Columns["PurchasePrice"].DefaultCellStyle.Format = "#,##0";
            dgvItemList.Columns["BookValue"].DefaultCellStyle.Format = "#,##0";
            dgvItemList.Columns["PurchasePrice"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvItemList.Columns["BookValue"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvItemList.Columns["ItemId"].DefaultCellStyle.Format = "000";
        }

        /// <summary>
        /// データベースから全資産データを読み込んで表（DataGridView）に表示する処理
        /// </summary>
        private void DisplayData()
        {
            try
            {
                ItemDao dao = new ItemDao();
                dgvItemList.DataSource = dao.GetAll();

                // 成功時はエラーメッセージをクリア
                lblErrorMessage.Text = "";
            }
            catch (Exception)
            {
                lblErrorMessage.Text = "データベースへ接続できません。";
            }
        }

        /// <summary>
        /// 検索ボタンクリック時の処理
        /// </summary>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                ItemDao dao = new ItemDao();

                // 検索実行
                var list = dao.SearchByName(txtSearchKeyword.Text);

                if (list == null || list.Count == 0)
                {
                    // 0件の場合は全件表示に戻す
                    DisplayData();

                    // DisplayDataでエラーメッセージがクリアされるため、直後に上書き設定する
                    // （※DisplayData内でDB接続エラーが出ている場合はそのままエラーメッセージが残る）
                    if (lblErrorMessage.Text == "")
                    {
                        lblErrorMessage.Text = "該当する資産が存在しません。";
                    }
                }
                else
                {
                    dgvItemList.DataSource = list;
                    lblErrorMessage.Text = "";
                }
            }
            catch (OracleException)
            {
                lblErrorMessage.Text = "データベースへ接続できません。";
            }
            catch (Exception)
            {
                lblErrorMessage.Text = "データベースへ接続できません。";
            }
        }

        /// <summary>
        /// 検索キーワード入力欄でEnterキーが押された時の処理
        /// </summary>
        private void txtSearchKeyword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch.PerformClick();
            }
        }

        /// <summary>
        /// 「新規登録」ボタンが押された時の処理
        /// </summary>
        private void btnOpenRegister_Click(object sender, EventArgs e)
        {
            frmItemRegister registerForm = new frmItemRegister();

            if (registerForm.ShowDialog() == DialogResult.OK)
            {
                DisplayData();
            }
        }

        /// <summary>
        /// 表（DataGridView）のセルがクリックされた時の処理
        /// </summary>
        private void dgvItemList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            selectedItemId = Convert.ToInt32(
                dgvItemList.Rows[e.RowIndex].Cells["ItemId"].Value);
        }

        /// <summary>
        /// 「削除」ボタンが押された時の処理
        /// </summary>
        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (dgvItemList.SelectedRows.Count == 0)
            {
                lblErrorMessage.Text = "削除する資産を選択してください。";
                return;
            }

            int selectedItemId = Convert.ToInt32(dgvItemList.SelectedRows[0].Cells["ItemId"].Value);

            try
            {
                ItemDao dao = new ItemDao();

                bool result = dao.Delete(selectedItemId);

                if (result)
                {
                    lblErrorMessage.Text = "";
                    DisplayData();
                }
                else
                {
                    lblErrorMessage.Text = "資産情報の削除に失敗しました。";
                }
            }
            catch (OracleException)
            {
                lblErrorMessage.Text = "データベースへ接続できません。";
            }
            catch (Exception)
            {
                // DB切断時などネットワーク／タイムアウトエラー時はすべて接続エラーとする
                lblErrorMessage.Text = "データベースへ接続できません。";
            }
        }

        private void dgvItemList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}