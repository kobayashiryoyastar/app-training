﻿public class Validation
{
    /// <summary>
    /// 必須入力チェック
    /// 空文字や空白のみの場合は false を返す。
    /// </summary>
    public static bool IsInputNotEmpty(string value)
    {
        return !string.IsNullOrWhiteSpace(value);
    }

    /// <summary>
    /// 資産名文字数チェック
    /// 30文字以内なら true を返す。
    /// </summary>
    public static bool IsLengthValid(string itemName)
    {
        return itemName.Length <= 30;
    }

    /// <summary>
    /// 数値入力チェック
    /// 半角数字で入力されているか確認する。
    /// </summary>
    public static bool IsNumericValid(string value)
    {
        return decimal.TryParse(value, out _);
    }

    /// <summary>
    /// 1以上の数値かチェックする。
    /// </summary>
    public static bool IsGreaterThanZero(string value)
    {
        if (decimal.TryParse(value, out decimal number))
        {
            return number >= 1;
        }

        return false;
    }
}