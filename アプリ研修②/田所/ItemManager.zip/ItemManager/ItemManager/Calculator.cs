﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ItemManager
{
    public class Calculator
    {
        /// <summary>
        /// 帳簿価格を計算する。
        /// </summary>
        /// <param name="purchasePrice">取得金額</param>
        /// <param name="serviceLife">耐用年数（年）</param>
        /// <param name="purchaseDate">取得日</param>
        /// <returns>帳簿価格</returns>
        public decimal CalculateBookValue(decimal purchasePrice, int serviceLife, DateTime purchaseDate)
        {
            // 経過月数を計算
            int elapsedMonths =
                (DateTime.Today.Year - purchaseDate.Year) * 12
                + DateTime.Today.Month - purchaseDate.Month;

            // マイナスにならないようにする
            if (elapsedMonths < 0)
            {
                elapsedMonths = 0;
            }

            // 耐用年数（月）
            int totalMonths = serviceLife * 12;

            // 1か月あたりの減価償却費
            decimal monthlyDepreciation = purchasePrice / totalMonths;

            // 現在までの減価償却費
            decimal depreciation = monthlyDepreciation * elapsedMonths;

            // 帳簿価格
            decimal bookValue = purchasePrice - depreciation;

            // 帳簿価格は最低1円
            if (bookValue < 1)
            {
                bookValue = 1;
            }

            return Math.Floor(bookValue);
        }

        /// <summary>
        /// 償却状態を取得する。
        /// </summary>
        /// <param name="bookValue">帳簿価格</param>
        /// <returns>ステータス</returns>
        public string GetStatus(decimal bookValue)
        {
            if (bookValue <= 1)
            {
                return "償却完了";
            }

            return "償却中";
        }
    }
}
