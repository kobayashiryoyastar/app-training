﻿using System;
using System.Collections.Generic;
using System.Text;
using Oracle.ManagedDataAccess.Client;

namespace ItemManager
{
    public class ItemDao
    {
        // 接続文字列（環境・設定に合わせて変更してください）
        private readonly string connectionString = "User Id=SYSTEM;Password=admin;Data Source=localhost:1521/xe;Connection Timeout=3;";

        /// <summary>
        /// コネクションプールからデータベース接続を取り出して開く
        /// </summary>
        /// <returns>開いたOracleConnectionオブジェクト</returns>
        public OracleConnection OpenConnection()
        {
            var connection = new OracleConnection(connectionString);
            try
            {
                connection.Open();
                return connection;
            }
            catch (Exception)
            {

                // 接続に失敗した場合は作成途中のオブジェクトを安全に破棄
                connection?.Dispose();

                // 壊れた接続がプールに残るのを防ぐためプールをクリア
                OracleConnection.ClearPool(connection);

                throw; // 上位のキャッチ処理へ渡す
            }
        }

        /// <summary>
        /// 使用し終わったDB接続を閉じる（プールへ返却・リソース解放）
        /// </summary>
        /// <param name="connection">閉じるOracleConnection</param>
        public void CloseConnection(OracleConnection connection)
        {
            if (connection != null)
            {
                try
                {
                    // Open状態でなくてもCloseを試みる（安全策）
                    if (connection.State == System.Data.ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
                catch
                {
                    // Close時に例外が出ても無視してDisposeを確実に行う
                }
                finally
                {
                    // どんな状態であっても必ずリソースを破棄する
                    connection.Dispose();
                }
            }
        }

        /// <summary>
        /// DBへ SELECT 文を発行し、すべての資産データを取得する
        /// </summary>
        /// <returns>資産リスト</returns>
        public List<Item> GetAll()
        {
            var itemList = new List<Item>();

            string sql = "SELECT ITEM_ID, ITEM_NAME, PURCHASE_DATE, PURCHASE_PRICE, SERVICE_LIFE FROM ITEMS ORDER BY ITEM_ID";

            using (OracleConnection conn = OpenConnection())
            using (OracleCommand cmd = new OracleCommand(sql, conn))
            using (OracleDataReader reader = cmd.ExecuteReader())
            {
                Calculator calculator = new Calculator();

                while (reader.Read())
                {
                    var item = new Item
                    {
                        ItemId = Convert.ToInt32(reader["ITEM_ID"]),
                        ItemName = Convert.ToString(reader["ITEM_NAME"]) ?? "",
                        PurchaseDate = Convert.ToDateTime(reader["PURCHASE_DATE"]),
                        PurchasePrice = Convert.ToDecimal(reader["PURCHASE_PRICE"]),
                        ServiceLife = Convert.ToInt32(reader["SERVICE_LIFE"])
                    };

                    item.BookValue =
                        calculator.CalculateBookValue(
                            item.PurchasePrice,
                            item.ServiceLife,
                            item.PurchaseDate);

                    item.Status =
                        calculator.GetStatus(item.BookValue);

                    itemList.Add(item);
                }
            }

            return itemList;
        }

        /// <summary>
        /// DBへ WHERE 条件付きの SELECT 文を発行し、キーワードに一致する資産データを取得する
        /// </summary>
        /// <param name="keyword">検索キーワード</param>
        /// <returns>該当する資産リスト</returns>
        public List<Item> SearchByName(string keyword)
        {
            var itemList = new List<Item>();

            string sql =
                @"SELECT ITEM_ID, ITEM_NAME, PURCHASE_DATE,
                 PURCHASE_PRICE, SERVICE_LIFE
          FROM ITEMS
          WHERE ITEM_NAME LIKE :Keyword
          ORDER BY ITEM_ID";

            using (OracleConnection conn = OpenConnection())
            using (OracleCommand cmd = new OracleCommand(sql, conn))
            {
                cmd.Parameters.Add(
                    new OracleParameter("Keyword", "%" + keyword + "%"));

                using (OracleDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Calculator calculator = new Calculator();

                        Item item = new Item();

                        item.ItemId = Convert.ToInt32(reader["ITEM_ID"]);
                        item.ItemName = Convert.ToString(reader["ITEM_NAME"]) ?? "";
                        item.PurchaseDate = Convert.ToDateTime(reader["PURCHASE_DATE"]);
                        item.PurchasePrice = Convert.ToDecimal(reader["PURCHASE_PRICE"]);
                        item.ServiceLife = Convert.ToInt32(reader["SERVICE_LIFE"]);

                        item.BookValue =
                            calculator.CalculateBookValue(
                                item.PurchasePrice,
                                item.ServiceLife,
                                item.PurchaseDate);

                        item.Status =
                            calculator.GetStatus(item.BookValue);

                        itemList.Add(item);
                    }
                }
            }

            return itemList;
        }

        /// <summary>
        /// DBへ INSERT 文を発行し、新しい資産データを保存する
        /// </summary>
        public bool Insert(Item item)
        {
            string sql =
             @"INSERT INTO ITEMS
      (
          ITEM_ID,
          ITEM_NAME,
          PURCHASE_DATE,
          PURCHASE_PRICE,
          SERVICE_LIFE
      )
      VALUES
      (
          ITEM_ID_SEQ.NEXTVAL,
          :ItemName,
          TRUNC(:PurchaseDate),
          :PurchasePrice,
          :ServiceLife
      )";

            using (OracleConnection conn = OpenConnection())
            using (OracleTransaction tran = conn.BeginTransaction())
            using (OracleCommand cmd = new OracleCommand(sql, conn))
            {
                // ★ タイムアウトを3秒に指定（これで切断時に無限待ちしなくなります）
                cmd.CommandTimeout = 3;

                cmd.Transaction = tran;
                cmd.Parameters.Add(new OracleParameter("ItemName", item.ItemName));
                cmd.Parameters.Add(new OracleParameter("PurchaseDate", item.PurchaseDate));
                cmd.Parameters.Add(new OracleParameter("PurchasePrice", item.PurchasePrice));
                cmd.Parameters.Add(new OracleParameter("ServiceLife", item.ServiceLife));

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    tran.Commit();
                    return true;
                }
                else
                {
                    tran.Rollback();
                    return false;
                }
            }
        }


        /// <param name="itemId">資産ID</param>
        /// <returns>成功時 true / 失敗時 false</returns>
        public bool Delete(int itemId)
        {
            string sql = "DELETE FROM ITEMS WHERE ITEM_ID = :ItemId";

            // こちらも try-catch を除去して呼び出し元へ例外を伝搬させます
            using (OracleConnection conn = OpenConnection())
            using (OracleTransaction tran = conn.BeginTransaction())
            using (OracleCommand cmd = new OracleCommand(sql, conn))
            {
                cmd.Transaction = tran;
                cmd.Parameters.Add(new OracleParameter("ItemId", itemId));

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    tran.Commit();
                    return true;
                }
                else
                {
                    tran.Rollback();
                    return false;
                }
            }
        }
    }
}
    

